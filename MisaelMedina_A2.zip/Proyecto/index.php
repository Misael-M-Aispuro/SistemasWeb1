<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Captura de Datos</title>
    <script src="https://kit.fontawesome.com/a7107a89a.js" crossorigin="anonymous"> </script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
   <div class="dive">
     <h1>Captura de Datos Personales</h1>
    <br>
    <h2>Ingresa los datos que se te piden</h2>
    <br>
    <p><center>Mi primera encuesta</center></p>
    <hr>
    <form action="resultados.php" method="POST">
        <center>
        <label for="Name">Nombre</label>
        <input type="text" id="Name" name="Name" value="Ingresa tu nombre"> <hr>
        <label for="Age">Edad</label>
        <input type="number" id="Age" name="Age" value="Ingresa tu edad"> <hr>
        <label for="City">Ciudad donde vives</label>
        <input type="text" id="City" name="City" value="Ingresa tu ciudad donde vives"> <hr>
        <label for="Birthday">Fecha de Nacimiento</label>
        <input type="date" id="Birthday" name="Birthday"> <hr>
        <label for="Hobby">Pasatiempo favorito</label>
        <input type="text" id="Hobby" name="Hobby" value="Ingresa tu pasatiempo favorito"> <hr>
        <button type="submit" >¡Ingresamos Datos!</button>

        </center>    
    </form>
   </div>

</body>
</html>
    